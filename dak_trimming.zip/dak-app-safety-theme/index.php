<?php get_header(); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1>
            <?php if (get_theme_mod('hero_title')) : ?>
                <?php echo esc_html(get_theme_mod('hero_title')); ?>
            <?php else : ?>
                See Exactly Which Apps Are Putting Your Kids at Risk
            <?php endif; ?>
        </h1>
    </div>
</section>

<!-- Video Demo Section -->
<section class="video-section">
    <div class="container">
        <h2 class="section-title">
            <?php if (get_theme_mod('video_section_title')) : ?>
                <?php echo esc_html(get_theme_mod('video_section_title')); ?>
            <?php else : ?>
                Watch the Live Demo
            <?php endif; ?>
        </h2>

        <div class="video-container">
            <div class="video-placeholder" onclick="playVideo()">
                <div class="play-button"></div>
                <div class="video-text">
                    <strong>Click to watch the demo</strong><br>
                    See how easy it is to protect your kids online
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Try App Section -->
<section class="try-app-section">
    <div class="container">
        <div class="try-app-content">
            <h2>Ready to Protect Your Kids?</h2>
            <p>Test our App Safety Search Engine right now - no signup required!</p>
            <a href="https://app-search-engine-demo.streamlit.app/" class="try-app-button" target="_blank" rel="noopener noreferrer">
                Try the App for Free!
            </a>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <h2 class="section-title">
            <?php if (get_theme_mod('features_title')) : ?>
                <?php echo esc_html(get_theme_mod('features_title')); ?>
            <?php else : ?>
                Everything You Need to Protect Your Kids
            <?php endif; ?>
        </h2>
        <p class="section-subtitle">
            <?php if (get_theme_mod('features_subtitle')) : ?>
                <?php echo esc_html(get_theme_mod('features_subtitle')); ?>
            <?php else : ?>
                Comprehensive app safety analysis backed by real FBI data and academic research
            <?php endif; ?>
        </p>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">🔍</div>
                <h3 class="feature-title">Instant App Analysis</h3>
                <p class="feature-description">Search any app instantly and get detailed safety information. Our database covers 120+ popular apps that kids use daily.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">⚠️</div>
                <h3 class="feature-title">Predator Risk Assessment</h3>
                <p class="feature-description">Get customized risk levels based on 10,000+ FBI child predator press releases. See which apps are most dangerous for your child's age group.</p>
            </div>
                       
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3 class="feature-title">Demographic-Based Alerts</h3>
                <p class="feature-description">Receive targeted warnings based on your child's specific demographics - age, gender, and interests that predators typically target.</p>
            </div>
            
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <h2 class="section-title">The Numbers Don't Lie</h2>
        <p class="section-subtitle">Real data that shows why this protection is critical</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-number">10,000+</span>
                <span class="stat-label">FBI Reports Analyzed</span>
            </div>
            <div class="stat-card">
                <span class="stat-number">120+</span>
                <span class="stat-label">Apps in Database</span>
            </div>
            <div class="stat-card">
                <span class="stat-number">89%</span>
                <span class="stat-label">of Parents Unaware</span>
            </div>
            <div class="stat-card">
                <span class="stat-number">24/7</span>
                <span class="stat-label">Protection Coverage</span>
            </div>
        </div>
    </div>
</section>

<!-- Pricing Section -->
<section class="pricing-section">
    <div class="container">
        <h2 class="section-title">Protect Your Kids Today</h2>
        <p class="section-subtitle">For less than a latte.</p>
        
        <div class="pricing-card">
            <div class="pricing-badge">Most Popular</div>
            <div class="price">
                <?php if (get_theme_mod('price_amount')) : ?>
                    <?php echo esc_html(get_theme_mod('price_amount')); ?>
                <?php else : ?>
                    $5/month
                <?php endif; ?>
            </div>
            
            <ul class="features-list">
                <li>Complete access to App Safety Search Engine</li>
                <li>Search 120+ apps instantly</li>
                <li>FBI-backed predator risk analysis</li>
                <li>Demographic-specific safety alerts</li>
                <li>Bi-weekly app database updates</li>
                <li>30-day money-back guarantee</li>
                <li>Instant access after purchase</li>
            </ul>
            
            <a href="#" class="cta-button" onclick="handlePurchase()">Get Instant Access Now</a>
        </div>
    </div>
</section>

<!-- Try App Section 2 -->
<section class="try-app-section">
    <div class="container">
        <div class="try-app-content">
            <h2>Still Not Sure? Try It First!</h2>
            <p>Experience the power of our App Safety Search Engine before you commit. No credit card required!</p>
            <a href="https://app-search-engine-demo.streamlit.app/" class="try-app-button" target="_blank" rel="noopener noreferrer">
                Try the App for Free!
            </a>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <h2 class="section-title">Frequently Asked Questions</h2>
        
        <div class="faq-list">
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    How current is the FBI data?
                    <span>+</span>
                </div>
                <div class="faq-answer" style="display: none;">
                    Our database is built from over 10,000 FBI child predator press releases and is regularly updated as new cases and patterns emerge. The academic research component ensures we're using the most current methodologies for risk assessment.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    What devices does this work on?
                    <span>+</span>
                </div>
                <div class="faq-answer" style="display: none;">
                    The App Safety Search Engine is web-based and works on any device with internet access - computers, tablets, and smartphones. No installation required.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    Is there a money-back guarantee?
                    <span>+</span>
                </div>
                <div class="faq-answer" style="display: none;">
                    Yes! We offer a 30-day money-back guarantee. If you're not completely satisfied with the App Safety Search Engine, contact us within 30 days for a full refund.
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question" onclick="toggleFAQ(this)">
                    How often is the database updated?
                    <span>+</span>
                </div>
                <div class="faq-answer" style="display: none;">
                    We update our database monthly with new app safety information, emerging threats, and the latest research findings. All updates are included in your one-time purchase.
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer CTA -->
<section class="hero" style="padding: 60px 0; background: rgba(255, 255, 255, 0.02);">
    <div class="container">
        <h2 style="font-size: 2.5rem; margin-bottom: 20px;">Don't Wait - Protect Your Kids Now</h2>
        <p class="hero-subtitle" style="margin-bottom: 40px;">Every day you wait is another day your children could be at risk. Get instant access to the protection they need.</p>
        <a href="#" class="cta-button" onclick="handlePurchase()">
            <?php if (get_theme_mod('cta_button_text')) : ?>
                <?php echo esc_html(get_theme_mod('cta_button_text')); ?>
            <?php else : ?>
                Get Started Today - $5
            <?php endif; ?>
        </a>
    </div>
</section>

<!-- Contact Section -->
<section class="contact-section" style="padding: 80px 0; background: rgba(255, 255, 255, 0.05);">
    <div class="container">
        <div style="text-align: center; max-width: 600px; margin: 0 auto;">
            <h2 class="section-title" style="margin-bottom: 20px;">Have Questions? We're Here to Help</h2>
            <p class="section-subtitle" style="margin-bottom: 40px;">
                Get in touch with our team for support, questions, or feedback about keeping your kids safe online.
            </p>
            <div style="background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 20px; padding: 40px;">
                <div style="display: flex; align-items: center; justify-content: center; gap: 16px; margin-bottom: 20px;">
                    <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #4ECDC4, #A8E6CF); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px;">
                        ✉️
                    </div>
                    <div>
                        <h3 style="color: #ffffff; font-size: 1.2rem; margin-bottom: 8px;">Email Us</h3>
                        <a href="mailto:brandon@defendallkids.com" style="color: #4ECDC4; font-size: 1.1rem; text-decoration: none; font-weight: 600;">
                            brandon@defendallkids.com
                        </a>
                    </div>
                </div>
                <p style="color: #B8B8B8; font-size: 0.95rem; line-height: 1.6;">
                    We typically respond within 24 hours. Whether you have technical questions, need help with your subscription, or want to share feedback - we're here to help protect your family.
                </p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
